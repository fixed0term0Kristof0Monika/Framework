.. tenma-serial documentation master file, created by
   sphinx-quickstart on Fri Jul  3 10:44:53 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to tenma-serial's documentation!
========================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   library/api
   tools/tenma-control
   tools/tenma-applet



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
