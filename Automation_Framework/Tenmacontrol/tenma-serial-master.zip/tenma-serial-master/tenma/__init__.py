from .tenmaDcLib import *
